$(document).ready(function(){
	var heightWrapper = $('#wrapper').height();
	var heightHeader = $('#header').height();
	var heightMain = $("#main").height();
	var height = 0;
	
	height = heightWrapper - (heightHeader + $('#footer').height());
	
	if (heightMain <= height) {
		$("#main").height(height);
	}
});

SyntaxHighlighter.all();
        	
        	
